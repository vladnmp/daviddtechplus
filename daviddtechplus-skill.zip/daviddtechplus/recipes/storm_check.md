# Storm check

How bumpy the coming week could be: the market first, then the member's own symbols.

1. Market backdrop (free): storm level and swing odds of the eight reference markets, and the next scheduled events (US releases, Fed decisions, US half-days).
2. Optional scan of the member's list (1 request) for their storm levels side by side.

**Shows:** Storm levels with their meaning. Storm level 1-5: the 5-step swing chance as a multiple of its usual rate (1 under 0.7x calm, 2 normal, 3 from 1.15x choppy, 4 from 1.55x stormy, 5 from 2x very stormy); the size of moves only, up or down alike.

**Cost:** Free, or 1 request with the scan.

**Pairs well with:** Watchlist triage (`watchlist_triage`), Close check (`after_close_desk`)

Daily requests: a brief, a scan (up to 10 symbols) or a DCA pacing call is 1 request each; re-reading a brief already pulled today (same symbol, horizon and data) is free; the market backdrop, capabilities, recipes, the supported list and the usage check are free.

*Source: DaviddTech+ (skool.com/daviddtech/about)*
